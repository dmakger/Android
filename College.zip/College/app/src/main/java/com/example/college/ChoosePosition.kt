package com.example.college

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity

class ChoosePosition : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_choose_position)
    }

    fun onPositionClick(view: View) {
        intent = when(view.id) {
            R.id.student -> Intent(this, StudentRegistration::class.java)
            R.id.teacher -> Intent(this, TeacherRegistration::class.java)
            else -> null
        }
        if (intent != null)
            startActivity(intent)
    }
}