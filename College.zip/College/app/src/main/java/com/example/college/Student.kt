package com.example.college

class Student(
    val id: String? = null,
    val login: String? = null,
    val email: String? = null,
    val password: String? = null,
    var repeat_password: String? = null
) {
    fun isValid() : Boolean {
        return !isEmpty() && isPasswordEquals()
    }

    fun isEmpty() : Boolean {
        return id.isNullOrBlank()
                || login.isNullOrBlank()
                || email.isNullOrBlank()
                || password.isNullOrBlank()
                || repeat_password.isNullOrBlank()
    }

    fun isPasswordEquals() = password.equals(repeat_password)
}