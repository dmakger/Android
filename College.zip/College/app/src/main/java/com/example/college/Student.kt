package com.example.college

class Student(
    val id: String,
    val login: String,
    val email: String,
    val password: String,
) : User();