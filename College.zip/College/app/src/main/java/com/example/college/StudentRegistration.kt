package com.example.college

import android.os.Bundle
import android.support.v4.os.IResultReceiver
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase


class StudentRegistration : AppCompatActivity() {

    private val database = Firebase.database
    private lateinit var dbRef: DatabaseReference
    private val STUDENT_KEY = "Student"

    private lateinit var login: EditText
    private lateinit var email: EditText
    private lateinit var password: EditText
    private lateinit var repeat_password: EditText


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_student_registration)

        init()
    }

    private fun init() {
        login = findViewById<EditText>(R.id.et_login)
        email = findViewById<EditText>(R.id.et_email)
        password = findViewById<EditText>(R.id.et_password)
        repeat_password = findViewById<EditText>(R.id.et_repeat_password)
        dbRef = database.getReference(STUDENT_KEY)
    }


    fun onSignUpClick(view: View) {
        val id = dbRef.key
        val login = this.login.text.toString()
        val email = this.email.text.toString()
        val password = this.password.text.toString()
        val repeat_password = this.repeat_password.text.toString()
        val newStudent = Student(id, login, email, password, repeat_password)

        if (newStudent.isEmpty()) {
            Toast.makeText(this, "Exists empty value", Toast.LENGTH_SHORT).show()
        }
        if (!newStudent.isPasswordEquals()) {
            Toast.makeText(this, "Password not equals", Toast.LENGTH_SHORT).show()
        }
        if (newStudent.isValid()) {
            dbRef.push().setValue(newStudent)
            Toast.makeText(this, "Save", Toast.LENGTH_SHORT).show()
        }
    }
}