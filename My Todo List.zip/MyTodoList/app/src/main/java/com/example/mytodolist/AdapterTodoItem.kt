package com.example.mytodolist

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.listitem_todo.view.*


class AdapterTodoItem : RecyclerView.Adapter<AdapterTodoItem.MyViewHolder>() {
    private val list = ArrayList<TodoItem>()
    inner class MyViewHolder(parent: ViewGroup) : RecyclerView.ViewHolder(
        LayoutInflater.from(parent.context).inflate(R.layout.listitem_todo, parent, false)
    ) {
        fun bind(todoItem: TodoItem) = with(itemView) {
            txtTitle.text = todoItem.title
            txtDescription.text = todoItem.description
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = MyViewHolder(parent)

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.bind(list[position])
    }

    override fun getItemCount() = list.size

    fun addItem(todoItem: TodoItem) {
        list.add(todoItem)
        notifyItemInserted(list.size - 1)
    }
}