package com.example.mytodolist

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class TodoItem(var id: Int, var title: String, var description: String) : Parcelable